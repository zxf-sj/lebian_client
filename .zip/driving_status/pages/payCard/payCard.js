// driving_status/pages/payCard/payCard.js
const BASE_URL = require("../../../utils/BASE_URL");
var baseUrl = BASE_URL.BASE_URL //配置基础url
const debounce = require('../../../utils/debounce');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList: [],
    Phone: '',
    imgbaseUrl:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      imgbaseUrl:baseUrl
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let _this = this;
    _this.getList();
    this.setData({
      imgbaseUrl:baseUrl
    })
  },
  changeTel: debounce(function (e) {
    this.setData({
      Phone: e.detail.value
    })
  }, 500),
  payCard: debounce(function (e) {
    const _this = this;
    wx.showModal({
      title: '提示',
      content: '确认购买？',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.showLoading({
            title: '加载中',
          })
          
          const openid = wx.getStorageSync('openid');
          if (!openid) {
            wx.navigateTo({
              url: '/user_center/pages/login/login',
            })
            return false;
          }
          const Id = e.currentTarget.dataset.id;
          const user = wx.getStorageSync('userInfo');
          const request = {
            MemberId: user.Id,
            ProductId: Id,
            Quantity: 1,
            Referrerphone: _this.data.Phone
          }
          wx.request({
            url: baseUrl + '/api/CarPromotion/CreatMemberProducts',
            data: request,
            method: 'POST',
            success(res) {
              console.log(res)
              if (res.statusCode == 200) {
                const reqData = {
                  LayerOrder: '1',
                  Id: res.data.data,
                  url: ''
                }
                wx.request({
                  url: baseUrl + '/Api/DispatchMobile/ProductGoPay',
                  data: reqData,
                  method: "GET",
                  success(rts) {
                    const ress = rts.data.data;
                    const data = JSON.parse(ress);
                    console.log(data)
                    wx.requestPayment({
                      timeStamp: data.timeStamp,
                      nonceStr: data.nonceStr,
                      package: data.package,
                      signType: 'MD5',
                      paySign: data.paySign,
                      success(paymentRes) {
                        wx.showToast({
                          title: '支付成功',
                          icon: 'success',
                          duration: 2000,
                          success: function () {
                            wx.hideLoading()
                            _this.getList()
                            wx.navigateTo({
                              url: '/pages/index/index',
                            })
                          }
                        })
                      },
                      fail(paymentErr) {
                        wx.hideLoading()
                        console.log('拉起支付失败', paymentErr)
                      }
                    })
                  },
                })
              } else {
                wx.hideLoading()
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  }, 500),
  getList() {
    let _this = this;
    var userinfo = wx.getStorageSync('userInfo');
    if(!userinfo){
      wx.navigateTo({
        url: '/user_center/pages/login/login',
      })
    }
    wx.showLoading({
      title: '加载中',
    })
    let params = {
      MemberId:userinfo.Id
    }
    wx.request({
      url: baseUrl + '/api/CarPromotion/ProductList',
      data: params,
      method: "GET",
      success(res) {
        console.log(res)
        wx.hideLoading()
        if (res.data.code == 0) {
          _this.setData({
            dataList: res.data.data
          })
        }
      },
    })
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: '次卡系统',
      imageUrl: "/assets/images/share.jpg",
      path: "/driving_status/pages/payCard/payCard",
      success: (res) => {
        console.log("转发成功", res);
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    }
  },
  onShareTimeline() {
    return {
      title: '次卡系统',
      imageUrl: '/assets/images/share.jpg' // 自定义图片（建议尺寸 1080*1920）
    }
  }
})