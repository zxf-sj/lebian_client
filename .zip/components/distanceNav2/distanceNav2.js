Component({
  /**
   * 组件的属性列表
   */
  properties: {
    distanceNav_Data: {
      type: String,
      value: 'pc'
    },
    price:{
      type: String
    },
    typeon:{
      type: String
    },
  },
  observers: {
    'distanceNav_Data': function(newVal) {
      let pcTimeSync = wx.getStorageSync('pcTimeSync');
      let storageSync = wx.getStorageSync('storageSync');
      this.setData({
        propsTxt:pcTimeSync.propsTxt,
        propsDay:pcTimeSync.propsDay,
        startingCity:storageSync.startingCity,
        endingCity:storageSync.endingCity,
        StartTime:pcTimeSync.StartTime,
        EndTime:pcTimeSync.EndTime,
        Price:pcTimeSync.price,
      })
    },
    'price':function(newVal) {
      this.setData({
        Price:newVal
      })
    }
  },
  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      let pcTimeSync = wx.getStorageSync('pcTimeSync');
      let storageSync = wx.getStorageSync('storageSync');
      this.setData({
        propsTxt:pcTimeSync.propsTxt,
        propsDay:pcTimeSync.propsDay,
        startingCity:storageSync.startingCity,
        endingCity:storageSync.endingCity,
        StartTime:pcTimeSync.StartTime,
        EndTime:pcTimeSync.EndTime,
        Price:pcTimeSync.Price,
      })
     
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    propsTxt:'',
    propsDay:'',
    startingCity:'',
    endingCity:'',
    StartTime:'',
    EndTime:'',
    Price:'',
  },
  onLoad(){
    
  },
  /**
   * 组件的方法列表
   */

  methods: {
   
  }
})