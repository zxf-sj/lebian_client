const BASE_URL = require("../../utils/BASE_URL");
var baseUrl = BASE_URL.BASE_URL //配置基础url
import http from '../../utils/http.js';
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    distanceNav_Data: {
      type: String,
      value: ''
    },
    price:{
      type: Number,
      value: '',
      observer(newVal) {
        console.log('newVal', newVal)
        this.setData({
          Price: newVal
        })
      }
    }
  },
  observers: {
    'distanceNav_Data': function (newVal) {
      let _this = this;
      let pcTimeSync = wx.getStorageSync('pcTimeSync');
      let storageSync = wx.getStorageSync('storageSync');
      _this.setData({
        propsTxt: pcTimeSync.propsTxt,
        propsDay: pcTimeSync.propsDay,
        startingCity: storageSync.startingCity,
        endingCity: storageSync.endingCity,
        StartTime: pcTimeSync.StartTime,
        EndTime: pcTimeSync.EndTime,
        Price: pcTimeSync.price,
      })

    }
  },
  lifetimes: {
    attached: function () {
      // 在组件实例进入页面节点树时执行
      const _this = this;
      let date = new Date();
      let today = date.toISOString().split("T")[0]; // 获取今天的日期（格式：YYYY-MM-DD）
      // 设置结束日期为今天之后三天
      let endDate = new Date();
      endDate.setDate(endDate.getDate() + 3); // 增加三天
      let endDateString = endDate.toISOString().split("T")[0]; // 获取格式化后的日期字符串
      _this.setData({
        StartDay: today,
        EndDay: endDateString
      })
      let pcTimeSync = wx.getStorageSync('pcTimeSync');
      let storageSync = wx.getStorageSync('storageSync');
      _this.setData({
        propsTxt: pcTimeSync.propsTxt,
        propsDay: pcTimeSync.propsDay,
        startingCity: storageSync.startingCity,
        endingCity: storageSync.endingCity,
        StartTime: pcTimeSync.StartTime,
        EndTime: pcTimeSync.EndTime,
        Price: pcTimeSync.Price,
      })
      const currentYear = new Date().getFullYear();
      const dayList = pcTimeSync.propsDay.split('/')
      let dayValue = currentYear + '-' + dayList[0] + '-' + dayList[1]
      _this.setData({
        dayValue
      })
     
      const lineId = wx.getStorageSync("lineId")
      wx.request({
        url: baseUrl + '/api/DispatchMobile/GetLineEmptySeatNumAndPrice',
        data: {
          lineId: lineId,
          today: dayValue,
          IsExclusive: '100004-0000010002',
        },
        method: "GET",
        success: (res) => {
          if (res.data.code == 0) {
            let data = res.data.data
            const dataList = data.SeatData[0].SeatList;
            const newList = dataList.filter(item => item.SeatNum != 0)
            const TimeList = newList.map(item => {
              return `${item.StartTime} ~ ${item.EndTime}`;
            });
            _this.setData({
              TimeList
            })
          } else {
            wx.showToast({
              title: res.data.msg,
              icon: "error"
            })
          }
        },
        fail(res) {
          wx.hideLoading()
        },
        complete(res) {
          wx.hideLoading()
        }
      })
      _this.getLine();
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    propsTxt: '',
    propsDay: '',
    startingCity: '',
    endingCity: '',
    StartTime: '',
    EndTime: '',
    StartDay: '',
    EndDay: '',
    Price: '',
    date: '',
    dayValue: '',
    TimeList: [],
    addArr: [],
    time_seatNum:1
  },
  onLoad() {

  },
  onShow() {

  },
  /**
   * 组件的方法列表
   */

  methods: {
    //点击日期
    bindDateChange(e) {
      const _this = this;
      const dayValue = e.detail.value
      const days = ['星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
      const weeks = days[new Date(dayValue).getDay()];
      _this.setData({
        propsDay: dayValue.slice(5, 7) + '/' + dayValue.slice(8, 10),
        propsTxt: weeks,
        dayValue: dayValue
      })
      let storedData = wx.getStorageSync('pcTimeSync') || {};
      let updatedData = {
        ...storedData,
        propsDay: _this.data.propsDay,
        propsTxt: _this.data.propsTxt
      };
      wx.setStorageSync('pcTimeSync', updatedData);
      let storageSync = wx.getStorageSync('storageSync') || {};
      let updatedStorageSync = {
        ...storageSync,
        startDate: dayValue,
      };
      wx.setStorageSync('storageSync', updatedStorageSync);
      _this.getList()
      _this.triggerEvent('nav_change_date');
    },
    //请求列表
    getList() {
      const _this = this;
      const lineId = wx.getStorageSync("lineId")
      wx.showLoading({
        title: '加载中',
      })
      return new Promise((resolve) => {
        wx.request({
          url: baseUrl + '/api/DispatchMobile/GetLineEmptySeatNumAndPrice',
          data: {
            lineId: lineId,
            today: _this.data.dayValue,
            IsExclusive: '100004-0000010002',
          },
          method: "GET",
          success: (res) => {
            wx.hideLoading()
            if (res.data.code == 0) {
              let data = res.data.data
              console.log(data)
              const dataList = data.SeatData[0].SeatList;
              const newList = dataList.filter(item => item.SeatNum != 0)
              console.log(newList)
              const TimeList = newList.map(item => {
                return `${item.StartTime} ~ ${item.EndTime}`;
              });
              _this.setData({
                TimeList
              })
              console.log(dataList)
              let num = 0;
              for (let item of dataList) {
                if (item.SeatNum > 0) {
                  num++
                  _this.setData({
                    StartTime: item.StartTime,
                    EndTime: item.EndTime
                  })
                  let storedData = wx.getStorageSync('pcTimeSync') || {};
                  let updatedData = {
                    ...storedData,
                    EndTime: item.EndTime,
                    StartTime: item.StartTime
                  };
                  wx.setStorageSync('pcTimeSync', updatedData);
                  break;
                }
              }
              _this.setData({
                time_seatNum:num
              })
              if(num == 0) {
                _this.setData({
                  StartTime: '',
                  EndTime: ''
                })
                let storedData = wx.getStorageSync('pcTimeSync') || {};
                let updatedData = {
                  ...storedData,
                  EndTime: '',
                  StartTime: ''
                };
                wx.setStorageSync('pcTimeSync', updatedData);
              }
              if (_this.data.update == 'pc') {
                wx.setStorageSync('pcTypeId', data.PriceList[0].Id);
              }
              _this.triggerEvent('nav_change_date');
            } else {
              wx.showToast({
                title: res.data.msg,
                icon: "error"
              })
            }
            resolve(res)
          },
          fail(res) {
            wx.hideLoading()
          },
          complete(res) {
            wx.hideLoading()
          }
        })
      })
      
    },
    //点击路线
    bindPickerLine(e) {
      const _this = this;
      const index = e.detail.value
      let storageSync = wx.getStorageSync('storageSync') || {};
      let updatedStorageSync = {
        ...storageSync,
        EndLocation_Latitude: _this.data.addArr[index].EndLocation_Latitude,
        EndLocation_Longitude: _this.data.addArr[index].EndLocation_Longitude,
        StatingLocation_Latitude: _this.data.addArr[index].StatingLocation_Latitude,
        StatingLocation_Longitude: _this.data.addArr[index].StatingLocation_Longitude,
        endingCity: _this.data.addArr[index].EndLocation_Name,
        lineId: _this.data.addArr[index].Id,
        startingCity: _this.data.addArr[index].StatingLocation_Name,
      };
      wx.setStorageSync('storageSync', updatedStorageSync);
      const cityList = _this.data.addArr[index].Name.split('===>')
      _this.setData({
        startingCity: cityList[0],
        endingCity: cityList[1],
        Price: ''
      })
      wx.removeStorageSync('starInfo2')
      wx.removeStorageSync('endInfo2')
      wx.setStorageSync('lineId', _this.data.addArr[index].Id)
      //拼车通过Nav标签调起的路线选择 更改路线  同步更新到 information 组件
      getApp().eventCenter.emit('startingCity', _this.data.addArr[index].StatingLocation_Name)
      getApp().eventCenter.emit('endingCity', _this.data.addArr[index].EndLocation_Name)
      //更改路线后同步调用时间列表接口 更新时间数据  默认选择可出行项的第一项
      _this.getList()
      _this.triggerEvent('nav_change_line');
    },
    getCurrentDateMMDD() {
      const now = new Date();
      const month = String(now.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需+1
      const day = String(now.getDate()).padStart(2, '0');
      return `${month}/${day}`;
    },
    //点击时间段
    async bindPickerTime(e) {
      const index = e.detail.value
      const _this = this;
      const timeList = _this.data.TimeList[index].split('~')
      if (this.data.propsDay == _this.getCurrentDateMMDD()) {
        const timestamp = new Date().getTime();
        const THIRTY_MINUTES_MS = 30 * 60 * 1000; // 1800000
        let times = _this.data.TimeList[index].split('~');
        let startTime = times[0] + ":" +  times[1]
        const now = new Date();
        const [hours, minutes] = startTime.split(':').map(Number);
        now.setHours(hours, minutes, 0, 0);
        let newData = now.getTime(); // 返回时间戳（毫秒）
        // if (newData + THIRTY_MINUTES_MS <= timestamp) {
        //   wx.showToast({
        //     title: '时间段车位已满，请重新选择',
        //     icon: 'none',
        //   })
        // } else {
          _this.setData({
            StartTime: timeList[0],
            EndTime: timeList[1]
          })
          let storedData = wx.getStorageSync('pcTimeSync') || {};
          let updatedData = {
            ...storedData,
            EndTime: timeList[1],
            StartTime: timeList[0]
          };
          wx.setStorageSync('pcTimeSync', updatedData);
        // }
      } else {
        _this.setData({
          StartTime: timeList[0],
          EndTime: timeList[1]
        })
        let storedData = wx.getStorageSync('pcTimeSync') || {};
        let updatedData = {
          ...storedData,
          EndTime: timeList[1],
          StartTime: timeList[0]
        };
        wx.setStorageSync('pcTimeSync', updatedData);
      }
    },
    //获取路线
    getLine() {
      const _this = this;
      http.getRequest('/api/DispatchMobile/GetPassengerLinePrice', '', wx.getStorageSync('header'), res => {
        if (res.code == 0) {
          if (res.data.length > 0) {
            _this.setData({
              addArr: res.data,
            });
          }
        } else {
          wx.showToast({
            title: '数据请求失败，请稍后重试',
            icon: "error"
          })
        }
      }, err => {
        console.log(err)
      })
    }
  }
})