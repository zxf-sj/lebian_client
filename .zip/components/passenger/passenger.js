// components/slideCoupon/slideCoupon.js
import http from '../../utils/http.js';
let clickTimer = null;
Component({
  /**
   * 组件的属性列表
   */
  pageLifetimes: {
    show: function () {
      // 页面被展示
      this.getUserList()
    },
    hide: function () {
      // 页面被隐藏
    },
    resize: function (size) {
      // 页面尺寸变化
    }
  },
  properties: {
    passenger: {
      type: Boolean,
      value: true
    },
    typeon: {
      type: String,
      value: ''
    },
    personArr: {
      type: Object,
      value: '',
      observer(newVal) {
        // 在这里可以响应属性变化
        let _this = this;
        let dataList = _this.data.listData
        const result = dataList.map(item => ({
          ...item,
          selected: newVal.some(bItem => bItem.Id === item.Id)
        }));
        _this.setData({
          listData: result
        })
      }
    }
  },
  lifetimes: {
    attached: function () {
      // 在组件实例进入页面节点树时执行
      this.getUserList()
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
    },

  },
  /**
   * 组件的初始数据
   */
  data: {
    hasCoupon: [],
    listData: [],
    listData2: []
  },


  methods: {
    closePopup() {
      this.setData({
        passenger:false
      })
    },
    bindKeyInput(res) {
      const regex = /^\d+$/;
      let _this = this
      let filteredItems = ''
      if (regex.test(res.detail.value)) {
        filteredItems = _this.data.listData2.filter(item => {
          return item.Phone.includes(res.detail.value)
        });
      } else {
        filteredItems = _this.data.listData2.filter(item => {
          return item.RealName.includes(res.detail.value)
        });
      }

      _this.setData({
        listData: filteredItems
      })
    },

    //获取乘车人列表
    getUserList() {
      let that = this;
      var usreinfo = wx.getStorageSync('userInfo');
      http.getRequest("/Api/Mobile/AddressList?MemberId=" + usreinfo.Id, '', wx.getStorageSync('header'), res => {
        if (res.code == 0) {
          res.data.forEach(function (obj) {
            obj.selected = false; // 添加新的键值对
          });
          //   wx.setStorageSync('perList',res.data)
          that.setData({
            listData: res.data,
            listData2: res.data
          })
        }
      }, err => {
        return false;
      })
    },
    //到达底部
    scrollToLower: function (e) {

    },
    change: function (e) {
      var that = this;
      const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
      var goods = that.data.listData; // 获取购物车列表
      const selected = goods[index].selected; // 获取当前商品的选中状态
      goods[index].selected = !selected; // 改变状态
      that.setData({
        listData: goods,
      });
    },
    close() {
      let that = this;
      let personArr = that.data.listData.filter(item => item.selected)
      const hasAaa = personArr.some(item => item.isChildren === "100004-0000010002")
      if (hasAaa) {
        wx.setStorageSync('passengerList', personArr)
        if (that.data.typeon == 'pc') {
          that.triggerEvent('customEvent', personArr); // 触发事件，并传递数据
          that.setData({
            passenger: false
          })
        } else if (that.data.typeon == 'bc') {
          let SeatNumber = wx.getStorageSync('SeatNumber')
          if (personArr.length > SeatNumber) {
            wx.showToast({
              title: '乘车人数不能超过' + SeatNumber + '人',
              icon: 'none',
            })
          } else {
            that.triggerEvent('customEvent', personArr); // 触发事件，并传递数据
            that.setData({
              passenger: false
            })
          }
        }
      } else {
        wx.showToast({
          title: '儿童无法单独乘车',
          icon: 'none',
        })
      }
    },
    //修改信息
    revise(e) {

      let item = e.currentTarget.dataset.item
      wx.navigateTo({
        url: '/pages/addUser2/addUser2?item=' + JSON.stringify(item),
      })
    },
    //添加乘车人
    add() {
      wx.navigateTo({
        url: '/pages/addUser2/addUser2',
      })
    }
  }
})