import http from '../../../utils/http'
const app = getApp();
Page({
  data: {
    listData: null,
    loading:false,
    noMore:false,
    pageNo:1,
  },
  onLoad: function (options) {
    var userinfo = wx.getStorageSync('userInfo');
    if(!userinfo){
      wx.navigateTo({
        url: '/user_center/pages/login/login',
      })
    }
    this.getlist();
  },
  getlist(){
    let that = this;
    var userinfo = wx.getStorageSync('userInfo');
    http.getRequest("/api/CarPromotion/MyCouponList?MemberInfoId="+userinfo.Id+"&IsUse=100004-0000010002&page="+that.data.pageNo+"&limit=10",'',wx.getStorageSync('header'),res=>{
      console.log(res)
      if(res.code === 0){
        if(that.data.pageNo==1){
          let data = res.data;
          console.log(data)
          this.setData({
            listData:data  
          })
        }else{
          var listData = res.data
          console.log(this.data.listData.concat(listData))
          that.setData({
            listData: this.data.listData.concat(listData)
          })
        }
      }
    },err=>{
      console.log(err)
    })
  },
  scrollToLower: function (e) {
    this.setData({
      loading: true,
      pageNo: this.data.pageNo + 1
    });
    this.getlist();
},
  lingQu(e){
    wx.reLaunch({
      url: '/pages/index/index',
    })
  },
})